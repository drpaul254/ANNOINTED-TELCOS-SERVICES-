# ANNOINTED TELCOS SERVICES — Website V2

Static HTML/CSS/JavaScript. Ready for Vercel, cPanel, Netlify or other static hosting.

V2 includes:
- Dark navy/cyan telecom design
- Responsive mobile/desktop layout
- Six real project photographs supplied in this chat
- Fiber splicing and installation
- ISP/MikroTik networking
- WiFi/hotspot setup
- Network cabling
- CCTV
- Solar/electrical
- Router configuration
- Project gallery
- Pricing guide
- FAQ and process
- WhatsApp quotation form
- Click-to-call and WhatsApp
- SEO metadata and basic structured data

Before launch:
1. Replace YOUR-DOMAIN-HERE in index.html and sitemap.xml with your real domain.
2. Review prices and service wording.
3. Test WhatsApp and phone links.
4. Deploy the folder/ZIP to Vercel.

The quotation form opens WhatsApp; it does not store submissions in a database.
